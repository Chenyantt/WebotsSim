### 运行说明

该文件夹是一个ros2的工作空间目录，包含了两个包的源代码：four_wheel_steering_controller（四轮底盘的运动驱动程序包）、ranger_mini_v3（ranger小车的webots驱动程序包）。首先对两个包进行编译和安装。

```Shell
colcon build
source install/setup.bash
```

接着运行 ranger_mini_v3 的启动脚本即可：

```Shell
ros2 launch ranger_mini_v3 robot_launch.py
```

此时应该能够自动的打开webots，加载预设的世界文件和小车模型。可以在新的终端自行打开一个rviz来查看深度相机/视觉相机/雷达的可视化数据。

### 控制说明
在新的终端运行官方的一个控制键盘，就可以用对应按键控制小车的移动、自旋。
```Shell
 ros2 run teleop_twist_keyboard teleop_twist_keyboard
```